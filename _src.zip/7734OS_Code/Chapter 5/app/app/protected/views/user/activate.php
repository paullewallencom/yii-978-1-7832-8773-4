<div class="homepage-container">
	<div class="white-box">
	<h3>Your Account is Now Active</h3>
	<p>Thanks for activating your account. Your email address has been verified, and you now have full access to all of Socialii.</p>
	</div>
</div>
