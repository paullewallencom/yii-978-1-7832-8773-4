<div class="homepage-container">
	<div class="white-box">
		<h3>Password Successfully Reset!</h3>
		<p>Your password has successfully been reset. You may now <?php echo CHtml::link('login', $this->createUrl('site/login')); ?></p>
	</div>
</div>
