<div class="homepage-container">
	<div class="white-box">
		<h3>Forgot Password Link Sent!</h3>
		<p>We sent an email to you with instructions on how to reset your password.</p>
	</div>
</div>
