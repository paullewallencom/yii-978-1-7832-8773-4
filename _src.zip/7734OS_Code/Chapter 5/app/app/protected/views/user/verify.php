<div class="homepage-container">
	<div class="white-box">
		<h3>Your Email Address Has Been Changed!</h3>
		<p>Your new email address has been successfully verified and changes</p>
	</div>
</div>
