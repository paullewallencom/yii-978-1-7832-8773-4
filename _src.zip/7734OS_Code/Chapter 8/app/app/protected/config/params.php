<?php return array(
	'disqus' => array(
		'shortname' => 'ch6disqusexample',
	),
	'sendgrid' => array(
		'username' => '',
		'password' => '',
		'from' => ''
	),
	'hybridauth' => array(
		'providers' => array(
			'Twitter' => array(
				'enabled' => true,
				'keys' => array(
					'key' => 'c97tLi7fzrWt6JbgDj5k6wgnG',
					'secret' => 'OegV4VdTiFvmweZPSe68edXwJMgB4Jm9gIDzVA5amJr195jKPS'
				)
			)
		)
	)
);
