<?php return array(
	'/api/<controller:\w+>/<action:\w+>' => '/api/<controller>/<action>',
	'/api/<controller:\w+>/<action:\w+>/<id:\w+>' => '/api/<controller>/<action>'
);