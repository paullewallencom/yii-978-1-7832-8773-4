<h1 class="page-header">An Error Occured!</h1>
<?php echo $error['message']; ?>