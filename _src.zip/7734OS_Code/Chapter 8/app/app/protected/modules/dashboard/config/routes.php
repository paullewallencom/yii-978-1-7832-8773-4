<?php return array(
	'/dashboard/<controller:\w+>/save' => '/dashboard/<controller>/save'
);