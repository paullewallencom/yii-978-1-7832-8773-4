INSERT INTO `statuses` (`id`, `name`, `created`, `updated`) VALUES
(1, 'New', 1394920186, 1394920186),
(2, 'Updated', 1394920186, 1394920186),
(3, 'Awaiting Response', 1394920186, 1394920186),
(4, 'In Progress', 1394920186, 1394920186),
(5, 'Resolved', 1394920186, 1394920186);

INSERT INTO `roles` (`id`, `name`, `created`, `updated`) VALUES
(1, 'Customer', 1394920186, 1394920186),
(2, 'Supporter', 1394920186, 1394920186),
(3, 'Admin', 1394920186, 1394920186);

INSERT INTO `users` (`id`, `email`, `password`, `name`, `role_id`, `created`, `updated`) VALUES
(1, 'customer@example.com', '$2y$13$SjAJFTNr/EFKSuf7Y7UZgu8ViyySLQsICBt/PryluxqfwIP9j9ox2', 'Customer', 1, 1394920423, 1394920423),
(2, 'supporter@example.com', '$2y$13$0jZE/pPTct.8dg6a8wA5COAEDxBBDatQSb6drui/h.VAUvhr6Af8C', 'Supporter', 2, 1395009793, 1395009793),
(3, 'admin@example.com', '$2y$13$nxyPpyFrSbDaGB3/Jpy0uuwjjBESYUmh3rz9F9zws0s2iOVgawO.u', 'Admin', 3, 1395009798, 1395009798);