--------------- DO NOT EDIT BELOW THIS LINE ---------------
<div class="email">
	Hello <?php echo $user->name; ?>,<br /><br />

	This is a notification that a new issue (#<?php echo $issue->id; ?>) has been resolved.<br /><br />

	Thank you,<br />
	Issue Tracking System
</div>