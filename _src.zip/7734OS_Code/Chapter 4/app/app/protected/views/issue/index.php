<h3>My Issues</h3>
<?php $this->renderPartial('issues', array('model' => $issues)); ?>