<div class="jumbotron">
	<h1>Error <?php echo $error['code']; ?></h1>
	<p><?php echo $error['message']; ?></p>
</div>