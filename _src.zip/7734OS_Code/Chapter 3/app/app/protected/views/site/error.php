<pre>
	<?php print_r($error); ?>
</pre>