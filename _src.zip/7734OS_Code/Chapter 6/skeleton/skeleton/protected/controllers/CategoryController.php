<?php

class CategoryController extends CMSController
{
	public function actionIndex($id=1) {}
	public function actionRss() {}
}