<?php

class CMSUrlManager extends CUrlManager {}