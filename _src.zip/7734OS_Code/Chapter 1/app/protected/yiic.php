<?php

// change the following paths if necessary
$config=dirname(__FILE__).'/config/main.php';

$config = require($config);

require_once('/opt/frameworks/php/yii/framework/yiic.php');